# molfi — console design spec

The device is the app. Every screen lives inside one handheld chassis: graphite moulded body,
recessed black glass, one amber signal colour. Nothing floats on a web page.

Reference build: `Molfi Console.dc.html`. Where this doc and that file disagree, **the file
wins** — it is the thing that was measured.

**Out of scope:** menus, bottom sheets, popups and the screens behind them. Those live in
`apps/web/src/components/menu/` and are unchanged. This spec covers the chassis, the glass,
the deck, and their controls.

**Contents** — [1 Tokens](#1-tokens) · [2 Type](#2-type) · [3 The three surfaces](#3-the-three-surfaces) ·
[4 Depth without WebGL](#4-depth-without-webgl) · [5 Controls](#5-controls) ·
[6 On the glass](#6-on-the-glass) · [7 Layout](#7-layout) · [8 Motion](#8-motion) ·
[9 The mark](#9-the-mark) · [10 Rules](#10-rules) · [11 Open questions](#11-open-questions)

---

## 1. Tokens

Paste-ready in [`tokens.css`](tokens.css). The short version:

| Group | Values |
| --- | --- |
| Ground | `#0b0b0c` — always darker than the chassis |
| Chassis | `#3d4049` → `#2e3138` → `#242629` → `#1b1d21`, edge `#0f1013` |
| Recess | `#14161a` → `#2b2e35` (dark at top, lit lip at bottom) |
| Key cap | `#343840` → `#4d515b`, ink `rgba(255,255,255,.62)` |
| Glass | `#000` screen, `#0b0b0b` inset rows, `#0f0f0f` cards, `#171717` lines |
| Signal | amber `#ff9f0a`, green `#3ddc84`, red `#e8453c` |
| Accents | blue `#a8cef8`→`#3068b8`, gold `#fff3b8`→`#f5c518`→`#8a5f06`, purple `#8b5cf6` |
| Markets | BTC `#f7931a` dp 2 · ETH `#8098ee` dp 2 · STRK `#8b5cf6` dp 5 |
| Dim type | `#8a8a8a` (readable), `#5c5c5c` (decoration). **No third grey.** |

---

## 2. Type

Two families, both already loaded in `app/layout.tsx`: **IBM Plex Mono** (400/500/600) as
`--font-plex-mono`, **Bricolage Grotesque** (500/700/800) as `--font-display`. Never a third.

| Role | Family | Spec |
| --- | --- | --- |
| Labels, status, printed legends | Plex Mono | 9.5–11px, `letter-spacing .10–.18em`, UPPERCASE |
| Numbers read at a glance | Bricolage 700 | 17–38px, `tabular-nums` |
| Row values on glass | Plex Mono 400/600 | 10–12.5px, `tabular-nums` |

Every numeral is tabular. Every label is uppercase mono with tracking. No sans body copy on
the glass — the console has no paragraphs, it has printed legends.

---

## 3. The three surfaces

Everything is one of three materials. Do not invent a fourth.

### A · Chassis — moulded graphite, lit from above

```css
background: linear-gradient(168deg, #3d4049 0%, #2e3138 36%, #242629 82%, #1b1d21 100%);
box-shadow:
  inset 0  2px 0 rgba(255,255,255,.16),   /* lit top face    */
  inset 0 -4px 0 rgba(0,0,0,.5),          /* shadowed bottom */
  inset  3px 0 0 rgba(255,255,255,.05),   /* left highlight  */
  inset -3px 0 0 rgba(0,0,0,.28),         /* right falloff   */
  0 0 0 1px rgba(255,255,255,.07),        /* rim off the ground */
  0 3px 0 #0f1013,                        /* the moulded edge   */
  0 30px 70px rgba(0,0,0,.8), 0 8px 20px rgba(0,0,0,.55);
border-radius: 32px;
```

### B · Recess — any hole cut in the body

Inverted lighting: dark at the top, lit lip at the bottom.

```css
background: linear-gradient(180deg, #14161a, #2b2e35);
box-shadow:
  inset 0 3px 8px rgba(0,0,0,.75),
  inset 0 -1px 0 rgba(255,255,255,.1),
  0 1px 0 rgba(255,255,255,.09);
```

The glass sits **inside** a recess, never directly on the chassis. That double frame —
chassis → recess → black glass — is what makes it read as hardware. Radii nest **32 → 22 → 15**.

On a dark body every recess also needs a `1px rgba(255,255,255,.05)` inner rim; without it,
black glass on a dark chassis has no visible edge.

### C · Raised key — lit top, hard ledge under it

```css
box-shadow:
  inset 0  2px 0 rgba(255,255,255,.5),
  inset 0 -5px 0 rgba(0,0,0,.24),
  0 4px 0 <ledge>,
  0 7px 14px rgba(0,0,0,.4);
transition: transform 140ms cubic-bezier(.2,.9,.25,1),
            box-shadow 140ms cubic-bezier(.2,.9,.25,1);
```

Pressed: `transform: translateY(2px)`, the ledge collapses to `0 1px 0`, `transition-duration:
45ms`. Down fast, back up in its own time. **Every key must travel** — inline styles have no
`:active`, so this needs an explicit pressed state (`style-active` in the reference build).

---

## 4. Depth without WebGL

In order of how much each one carries:

1. **Nested recesses.** A key in a dark inset frame reads as inset hardware. The same key on
   a flat surface reads as a web button.
2. **Cross-axis gradients.** Flat faces get *vertical* gradients (light from above);
   cylinders get *horizontal* ones (the knob).
3. **Hard ledges, not blurred shadows.** `0 4px 0 <darker>` is plastic thickness.
   `0 4px 12px rgba(0,0,0,.3)` is a card on a website.
4. **Screens are cut in**, so they carry `inset 0 2px 8px rgba(0,0,0,.95)` plus a 1px light
   line under the bottom edge — the lip of the cutout catching light.

Reserve real WebGL (`Console3D`) for the marketing hero. The play screen must never depend on
a GPU context.

---

## 5. Controls

### Knob — the stake

The gold cylinder is a **control**, not decoration.

- 58px wide, flexes to fill its rail (104px floor), radius 13, `touch-action: none`,
  `cursor: grab`.
- Cylinder: horizontal gradient
  `#3d2802 → #a97a10 9% → #f0c236 26% → #fff3b8 41% → #f5c518 56% → #d9a30f 74% → #8a5f06 90% → #3d2802`.
- Ribs: `repeating-linear-gradient(180deg, rgba(0,0,0,.5) 0 1.5px, rgba(255,255,255,.26) 1.5px 3px, transparent 3px 12px)`,
  rotated by `background-position: 0 <-dragPx>px`. That single property is the whole illusion.
- End caps: `linear-gradient(180deg, rgba(0,0,0,.55), transparent)` 11px top, mirrored 13px
  bottom.
- Detent: 9 × 4 amber nub on the left edge, `top` as a **percentage** of the step range,
  `box-shadow: 0 0 8px rgba(255,159,10,.85)`.
- Input: drag (14px per detent), wheel, arrow keys. `TURN` printed underneath.

### Stake readout

Sits directly under the knob, so control and value are one unit: current step large, the
detents either side at `#8a8a8a`/9.5px. The ladder is legible without turning anything.
Never display a stake the market would refuse.

### Primary key

96 × 96, radius 12, in a `#0d0e10` recessed frame with 8px padding.
`linear-gradient(180deg, #f8675c, #f2564c 38%, #c8362e)`, ledge `#8f2621`. Carries the mark at
54px in `rgba(255,255,255,.95)`. Armed state: 2px white ring.

Bottom-right of the deck, always — it is the one control a thumb must find without looking.

### Utility key (blue)

`linear-gradient(180deg, #a8cef8, #6da5e8 44%, #3068b8)`, ledge `#204c88`, plus a vertical
hairline sheen `repeating-linear-gradient(90deg, rgba(255,255,255,.13) 0 1px, transparent 1px 4px)`.
Label mono 12px/600 `.1em` with `text-shadow: 0 1px 2px rgba(0,0,0,.45)`. Count badge on
`rgba(0,0,0,.34)` when it leads somewhere with items — **hidden at zero**.

### Band control

`BAND [−] ▓▓▓░░ [+] ±0.42%`, on the glass. Keys are `#1c1c1c` with amber glyphs; the fill is
`linear-gradient(90deg, #ff9f0a, #ffc247)`.

Drag-on-chart still works, but the keys are the primary path: dragging a 1px rule is
undiscoverable on a phone and imprecise with a thumb. `[` / `]` on desktop.

### Bottom rail — sound

`♪` cap plus a volume rail: `#1c1f24` track, `#f2564c → #d8382c` fill, a 15px `#ffc247` detent
cap at the fill's edge, three white ribs centred. Level printed to its right; `MUTE` when off,
and the `♪` glyph drops to `rgba(255,255,255,.32)`.

Sound lives next to the volume it controls. There is no transport/pause key — the market does
not stop.

### Market switcher

A **chip in the price header**, not a deck key: 19px coin disc (the mark only, no symbol text
inside it), the symbol, and a `▾`, on `#141414` with a 1px inner rim. It belongs beside the
price it changes, and a deck key for it costs 60px of chassis for one tap a session.

Coin tones and decimals come from `packages/sdk/src/markets.ts` — BTC `#f7931a` dp 2,
ETH `#8098ee` dp 2, STRK `#8b5cf6` dp **5**. There is no MON market; `COIN_TONE` in
`PlayScreen.tsx` still carries `MON: "#836ef9"` and no STRK entry, so STRK currently falls
back to Bitcoin orange — fix that map. Discs draw as
`radial-gradient(circle at 32% 26%, <tone>, rgba(0,0,0,.62))`.

**A position belongs to its market.** Record the market on the position when it is opened,
settle it against *that* market's price, and format its band with *that* market's `dp`.
Settling against whatever market happens to be selected turns a switch into a guaranteed
loss for every open position — and the chip makes switching the easy path. Position cards
lead with the symbol for the same reason.

### Deck pills

62 × 26 caps, `linear-gradient(180deg, #4d515b, #343840)`, ledge `#14161a`, label under them
in `--color-ink` at 8.5px/`.18em`.

The source's `MENU` and `HOME` pills are both **off this deck**: MENU opens the existing menu
sheet (out of scope here), and HOME routes somewhere this artifact has no equivalent for.
Either wire them to their real destinations or leave the slot empty — a pill that does
nothing is worse than a gap.

---

## 6. On the glass

### Status bar

Top row, `#0b0b0b` with a 1px `#191919` bottom border: network left, peers right, each with a
6px square green LED (`box-shadow: 0 0 6px rgba(61,220,132,.8)`). The only place chrome may
sit above content. Attract mode blinks `ATTRACT` here in amber.

### Price header

Token chip and price left; cutoff ring centre when a position is open; `AVAILABLE` and session
P&L right. Price at 34px Bricolage 700.

### Chart — 206px

Price walks in from the left in green with a gradient skirt; the band you are about to buy
projects right from the now-line at **60% width** as an amber dashed box. Everything right of
the dot has not happened yet. The burn overlay fills that box as the round runs down.

Seed the history as a **walk**, never a constant — 46 identical points draw a flat slab for
the first 32 seconds, which is every screenshot anyone takes.

### Cutoff ring

34px, 3px stroke, `#1e1e1e` track, amber draining anticlockwise, `#e8453c` under 20%
remaining, seconds in the middle. `+N` beside it when more than one position is riding.

### House battery

Ten 3 × 10 cells against the 80% utilisation cap: `#3ddc84` → `#ff9f0a` past 75% → `#e8453c`
at the cap, unlit `#242424`. Cells, not a bar — a bar invites reading a precise value off a
few pixels.

### Oracle strip

A **readout**, not a button: `PRAGMA <VERDICT>` left, `<n>src · <age>s · <drift>bps` right.
Verdicts: `FRESH` green, `AGEING`/`DRIFTED` amber, `STALE`/`THIN`/`UNREAD` red. Never hidden
behind a tap — a stale print doesn't settle one position wrongly, it settles every position in
that market wrongly at once.

### Position cards

Open positions as physical rows: `#0f0f0f`, 1px `#1b1b1b`, 3px amber left edge, radius 11.
Band range in white tabular, `stake · mult` in dim mono beneath, countdown right in amber
12px/600. Settled tape below at 1px gaps on `#080808`, one coloured LED per row. A session
strip is anchored to the bottom of the glass.

Empty states are printed legends — `NOTHING RIDING · FIRE A BAND`, `NO TAPE YET` — centred in
the region they occupy, never illustrations.

---

## 7. Layout

Mobile-first, 414px chassis.

```
chassis 10px padding, radius 32
├─ bezel 9px → glass radius 15        ONE fixed height for every screen
│   ├─ status bar
│   ├─ price header    token chip + price | cutoff ring | available + P&L
│   ├─ chart 206px
│   ├─ band control
│   ├─ house battery + round tiers
│   └─ oracle strip
├─ deck grid  1fr / 112px
│   ├─ left   PAYS panel · POSITIONS key
│   └─ right  knob (flexes) · primary key
├─ footer     stake readout
└─ bottom rail  ♪ · volume · level
```

Four structural rules, each of which was a bug first:

- **The deck is one grid, not stacked rows.** Stacked rows are each sized by their tallest
  child, which leaves dead chassis beside the short one. The right column is a continuous rail
  whose knob flexes to fill whatever height the left column takes.
- **Every screen inside the glass is one fixed height.** A per-screen `min-height` guess makes
  the device change size when you switch screens.
- **The flexing region is the scrolling one** (`flex:1; min-height:0; overflow-y:auto`), and
  its empty state centres.
- **One value, one control.** The knob owns the stake; the rail owns volume. Never give a
  number two controls.

Rhythm: 9px between deck blocks, 8px between rows on glass, 11px glass padding. One column
throughout — no side-by-side content on glass beyond a label/value pair.

Hit targets: 44px minimum on the deck. Glass rows may be 26–31px, being secondary and not
adjacent to anything else tappable.

Set `box-sizing: border-box` document-wide. Without it every `width` + `padding` pair inflates
by the padding, and a 112px frame measures 128.

---

## 8. Motion

| Event | Motion |
| --- | --- |
| Key press | `translateY(2px)`, 45ms down, 140ms back |
| Refusal | `shake` 260ms on the whole glass, with the reason printed |
| Settlement | ring expanding from the print on the price axis, 620ms |
| Win / loss | `pop` 240ms centred on the chart, colour-coded, cleared at 1.4s |
| Knob | ribs translate with the drag, 1:1, no easing |
| Price | one digit column rolls 180ms — shorter than the poll interval |
| Idle 45s | attract mode: the console fires real rounds until first touch |

`prefers-reduced-motion`: shorten everything to 120ms and drop shake / roll / coin-drop
entirely. Never remove a state change, only its travel.

---

## 9. The mark

**The band, rotated** — a rhombus with the price sealed at its centre. Two elements on a 64
grid, chunky hardware weight:

```svg
<path d="M32 8 L56 32 L32 56 L8 32 Z" fill="none" stroke="currentColor"
      stroke-width="9" stroke-linejoin="round"/>
<circle cx="32" cy="32" r="6" fill="currentColor"/>
```

- [`logo.svg`](logo.svg) — `currentColor`, so one file serves every ground.
- [`icon.svg`](icon.svg) — amber `#ff9f0a` on `#0b0b0b`, 14px radius, stroke at 7.5 and the
  rhombus inset to 15…49 so it holds at 16px. Replaces `apps/web/src/app/icon.svg`.

Rounded joins. Never a filter, never a gradient, never a second colour — it takes the ground's
(white on the red key, amber on black). It shares the wordmark's grammar: `Wordmark.tsx` draws
MOLFI from a 5 × 5 bitmap of plain rects, so the mark stays straight-edged too.

---

## 10. Rules

**Colour**

- One amber. If a second thing on screen is amber, one of them is wrong.
- Two background colours: black glass, graphite body. No gradient page backgrounds; the tiled
  device motif is the only ground.
- Two dim greys only. Anything a player must read is `#8a8a8a` at 9.5px or larger; `#5c5c5c`
  is decoration. A third grey disappears — `#3a3a3a` on black is 1.7:1.
- 4.5:1 minimum on glass text, 3:1 for headline-scale numerals.

**Content**

- Never put a number on the glass without a mono label above or beside it.
- Anything that takes money states the amount before it is pressed, in the same units.
- Print a fact once. The round tier belongs in the PAYS panel — repeating it on a position
  card beside a compressed countdown makes the card contradict itself.
- No emoji.
- No win probabilities. The multiplier is the contract; the model behind it is deliberately
  conservative, so a probability would read as a forecast it isn't.

**Behaviour**

- Never ship a key that can't fire. Quick stakes come from the legal $1–$10 ladder, not
  percentages of the balance — at any healthy balance a percentage row is entirely disabled.
  Same for badges: hide at zero rather than printing "0".
- Session P&L sums **settled** positions only. Never difference the balance: the stake is
  escrowed at open, so a balance diff reports a loss the moment a position is taken, while the
  count beside it still says nothing has settled.
- Every control does what its label says or it comes off the deck.

---

## 11. Open questions

**The 3D console's accent.** `packages/sdk/src/console-geometry.ts` is the ground truth for
the WebGL hero and had already moved off cream (`shell #1c2228`, `shellDark #12171b`,
`screen #04070a`) for the same reason this repaint did: "a device with eight bright plastics on
it competes with the only numbers on the page that matter." The 2D device now matches it —
except that its lit accent is **cyan** (`#4ec9e8`, emissive `[0.10,0.42,0.52]`) while the
console's signal is amber `#ff9f0a`. Pick one before the hero and the play screen share a page.
Changing the material entry is a one-line edit; changing the 2D signal colour is not.

**The demo clock.** Paper rounds compress every cutoff to ≤24s so the loop is visible, which is
why position cards print `DEMO CLOCK` under the countdown. Live positions should show the real
remaining time and drop that label.
