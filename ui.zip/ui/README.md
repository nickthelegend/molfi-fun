# molfi — console UI

The device is the app. Every screen lives inside one handheld chassis: graphite moulded body,
recessed black glass, one amber signal colour. Nothing floats on a web page.

| File | What it is |
| --- | --- |
| [`IMPLEMENT.md`](IMPLEMENT.md) | **Start here.** Ten tasks against real `apps/web/` paths — hand this to Claude Code. |
| [`DESIGN.md`](DESIGN.md) | The spec. Tokens, the three surfaces, every component, layout, motion, rules. |
| [`tokens.css`](tokens.css) | Paste-ready `@theme` block for `apps/web/src/app/globals.css`. |
| [`Molfi Console.dc.html`](Molfi%20Console.dc.html) | The working reference build. Open it in a browser. |
| [`logo.svg`](logo.svg) | The mark, `currentColor`. One file for every ground. |
| [`icon.svg`](icon.svg) | App icon — the mark in amber on the console's black glass. Replaces `apps/web/src/app/icon.svg`. |

Ask Claude Code to read `ui/IMPLEMENT.md` and work through it in order. Each task names its
files, cites the spec section, and ends in a state you can ship.

Where this folder and the reference build disagree, **the build wins** — it is the thing that
was measured.

## Scope

This covers the **device**: the chassis, the glass, the deck and their controls.

It does **not** cover menus, bottom sheets, popups or the screens behind them — those already
exist in `apps/web/src/components/menu/` (`MenuSheet.tsx`, `Sheet.tsx`, and the eleven views
they open) and are unchanged by this work.

## What changed from the current build

Nine things, in rough order of how much they matter:

1. **Cream → graphite.** The chassis now matches `packages/sdk/src/console-geometry.ts`, which
   had already moved off cream for the WebGL hero.
2. **The gold cylinder became a knob** — drag or scroll it to step the stake, with a detent
   indicator. It was a decorative coin stack.
3. **The band is settable with a thumb** — a `[−] ▓▓▓░░ [+]` row on the glass, instead of
   drag-only on the chart.
4. **The deck is one two-column grid** — a content stack beside a continuous control rail, so
   it cannot contain dead chassis.
5. **Sound and volume moved to a bottom rail**; the pause key is gone, because the market
   does not stop.
6. **Token switching moved into the price header** as a chip, freeing a whole deck row.
7. **Quick stakes replaced percentage keys** — the percentages were all disabled at any
   healthy balance.
8. **`TICKETS` → `POSITIONS`**, and open positions are physical cards with a settled tape
   beneath them.
9. **A new mark**: the band rotated, price sealed at the centre.
