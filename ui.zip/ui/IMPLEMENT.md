# Implementation brief

For Claude Code, against `apps/web/`. Work top to bottom — each task is independent and
shippable on its own. Specs and exact values live in [`DESIGN.md`](DESIGN.md); the measured
reference is `Molfi Console.dc.html` in this folder (open it in a browser and compare).

Everything below is Tailwind v4 + the existing CSS variables. No new dependencies. Keep the
paper/live desk hooks, the pricing engine, `RangeChart`'s canvas maths, and everything under
`components/menu/` exactly as they are.

---

## 1 · Repaint the chassis — graphite

**Files:** `src/app/globals.css`

Replace the shell/cap/ink values in `@theme` with [`tokens.css`](tokens.css). Then update the
three utilities in the same file, whose shadow stacks are hard-coded for a cream body:

- `.shell` → the chassis stack in DESIGN.md §3A (note the added `0 0 0 1px rgba(255,255,255,.07)`
  rim; a dark body has no edge against the ground without it).
- `.screen` → add `inset 0 0 0 1px rgba(255,255,255,.04)`, and drop the bottom white line to
  `.12`.
- `.tiled` → retint the SVG tile to `#121214` / `#0d0d0e` on `#0b0b0c`.

Add a recess utility (`.recess`) for the bezel and the PAYS frame — DESIGN.md §3B. Today the
bezel doesn't exist as its own layer.

`--color-ink` flips to `rgba(255,255,255,.62)`: check `DeckKey`, which prints its legend in it.

**Done when:** the ground is darker than the body, the glass has a visible edge, and no cream
remains outside `components/menu/`.

## 2 · Nest the glass in a bezel

**Files:** `src/components/device/DeviceFrame.tsx`, `src/components/PlayScreen.tsx`

The screen currently sits straight on the shell. Wrap `children`'s screen block in a `.recess`
at 9px padding, radius 22, so radii nest **32 → 22 → 15**. This double frame is most of what
makes it read as hardware.

Also delete the top rail from `DeviceFrame` (tasks 3 and 4 rehome it) — the glass starts at the
top of the chassis.

## 3 · Knob replaces the coin stack

**Files:** new `src/components/device/Knob.tsx`, `src/components/device/Controls.tsx`
(delete `CoinStack`), `src/components/PlayScreen.tsx`

Full spec in DESIGN.md §5. The essentials: a vertical cylinder (horizontal gradient), ribs as a
`repeating-linear-gradient` whose `background-position` follows the drag 1:1, an amber detent
nub positioned as a **percentage** of the step range, and `flex:1` so it fills its rail.

Input: pointer drag at 14px per detent, wheel, and arrow keys. It owns the stake — which means
`StakeRail` comes off the deck (task 4). One value, one control.

**Done when:** dragging the knob steps the stake, the ribs track the drag, and the stake
readout under it shows the detents either side.

## 4 · Sound to a bottom rail, pause gone

**Files:** `src/components/device/Controls.tsx` (`RailKey`, `StakeRail`),
`src/components/device/DeviceFrame.tsx`

Rebuild the old stake rail as a **volume** rail on a new bottom rail beside the `♪` key: same
red fill, ribs and amber detent cap. Delete the pause key — the market does not stop.

One scale drives both fill width and cap position, or the thumb drifts from the pointer:
`fill = volume * 100%`, `cap left = calc(volume% - 7.5px)`, input `= (clientX - rect.left) / rect.width`.

Wire the level to `usePrefs` alongside `prefs.sound`.

## 5 · Band control on the glass

**Files:** `src/components/PlayScreen.tsx`, `src/lib/useBand.ts`

Add a `BAND [−] ▓▓▓░░ [+] ±0.42%` row under the chart, calling `band.nudge` — DESIGN.md §5.
Keep `onDragEdge`; the keys are the primary path because dragging a 1px rule is undiscoverable
on a phone. `[` / `]` already exist on desktop.

## 6 · Market switcher into the price header

**Files:** `src/components/PlayScreen.tsx`, `src/components/device/Controls.tsx`
(delete `CoinKey`)

Replace the `RANGE · BTC` label with the chip from DESIGN.md §5: coin disc (mark only, no
symbol text inside), symbol, `▾`. Cycles `MARKETS` exactly as `CoinKey` did.

While you are in there, fix `COIN_TONE` in `PlayScreen.tsx`: it still carries `MON: "#836ef9"`
and has no `STRK` entry, so STRK renders in Bitcoin orange. The real list is
`packages/sdk/src/markets.ts` — BTC dp 2, ETH dp 2, STRK dp 5.

## 7 · Quick stakes instead of percentage keys

**Files:** `src/components/PlayScreen.tsx`

`PERCENT_PRESETS` is dead UI: the market floors a ticket at `DEFAULT_CONFIG.minStake` and caps
it at `maxStake`, so at any healthy balance every percentage lands outside that window and all
four keys render disabled. Replace with quick stakes drawn from `STAKE_STEPS` (`$1 / $2.50 /
$5 / $10`), which always fire.

Keep `AGAIN`, and keep it wired to `lastBand` — the shape of the last band the market actually
accepted.

## 8 · One deck grid

**Files:** `src/components/PlayScreen.tsx`

Collapse the three deck rows into one `grid-cols-[1fr_112px]`:

- left — PAYS panel, then the POSITIONS key
- right — the knob (`flex:1`), then the primary key at the bottom

Stacked rows are each sized by their tallest child, which leaves dead chassis beside the short
one. The primary key stays bottom-right: it is the one control a thumb must find without
looking. Add `*{box-sizing:border-box}` if it isn't already global.

## 9 · POSITIONS screen

**Files:** new `src/components/device/Positions.tsx`, `src/components/PlayScreen.tsx`

Rename throughout: the screen and its key are **POSITIONS**, never "tickets". Card and tape
specs in DESIGN.md §6.

Three things that were bugs in the reference build, so build them in from the start:

- **One fixed glass height for every screen**, or the device changes size when you switch.
- **The scrolling region is the one that flexes** (`flex-1 min-h-0 overflow-y-auto`), and its
  empty state centres in the region it occupies.
- **Session P&L sums settled positions only.** Never difference the balance — the stake is
  escrowed at open, so a balance diff reports a loss the moment a position is taken while the
  count beside it still says nothing has settled. `PlayScreen`'s existing `session` derivation
  is already correct; reuse it.

## 10 · The mark

**Files:** `src/app/icon.svg` ← [`icon.svg`](icon.svg), and drop [`logo.svg`](logo.svg) into
`src/components/`

Replace the pip-and-bar drawing with the band mark (DESIGN.md §9). Put it on the primary key at
54px in `rgba(255,255,255,.95)`, and check `opengraph-image.tsx`, which draws its own copy of
the old mark. `Wordmark.tsx` is unchanged — the mark shares its straight-edged grammar.

---

## Before you call it done

- Every raised key travels: `translateY(2px)` at 45ms down, 140ms back. The `.key:active` rule
  already in `globals.css` covers anything carrying `.key` — make sure every new control does.
- No text below 4.5:1 on the glass. Two dim greys only: `#8a8a8a` for anything a player must
  read at 9.5px+, `#5c5c5c` for decoration.
- No control that does nothing. If a key has no destination, take it off the deck.
- `prefers-reduced-motion` still shortens rather than removes.
- Both open questions in DESIGN.md §11 need a decision: the 3D console's cyan accent vs the
  console's amber, and what live positions show in place of `DEMO CLOCK`.
